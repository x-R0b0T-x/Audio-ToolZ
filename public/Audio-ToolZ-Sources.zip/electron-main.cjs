const { app, BrowserWindow, screen, session } = require('electron');
const fs = require('fs');
const path = require('path');

function loadWindowBounds() {
  const statePath = path.join(app.getPath('userData'), 'window-state.json');
  const fallback = { width: 1440, height: 900, isMaximized: false };
  try {
    const parsed = JSON.parse(fs.readFileSync(statePath, 'utf8'));
    if (typeof parsed.width === 'number' && typeof parsed.height === 'number') {
      const displays = screen.getAllDisplays();
      const visible =
        typeof parsed.x === 'number' &&
        typeof parsed.y === 'number' &&
        displays.some((d) => {
          const wa = d.workArea;
          return (
            parsed.x + 80 >= wa.x &&
            parsed.x <= wa.x + wa.width - 80 &&
            parsed.y + 40 >= wa.y &&
            parsed.y <= wa.y + wa.height - 40
          );
        });
      return {
        x: visible ? parsed.x : undefined,
        y: visible ? parsed.y : undefined,
        width: Math.max(820, parsed.width),
        height: Math.max(560, parsed.height),
        isMaximized: Boolean(parsed.isMaximized),
      };
    }
  } catch {}
  return fallback;
}

function saveWindowBounds(win) {
  if (!win || win.isDestroyed()) return;
  const statePath = path.join(app.getPath('userData'), 'window-state.json');
  try {
    const isMaximized = win.isMaximized();
    const bounds = isMaximized ? win.getNormalBounds() : win.getBounds();
    fs.mkdirSync(path.dirname(statePath), { recursive: true });
    fs.writeFileSync(
      statePath,
      JSON.stringify({
        x: bounds.x,
        y: bounds.y,
        width: bounds.width,
        height: bounds.height,
        isMaximized,
      }),
      'utf8'
    );
  } catch {}
}

function createWindow() {
  const state = loadWindowBounds();
  const win = new BrowserWindow({
    x: state.x,
    y: state.y,
    width: state.width,
    height: state.height,
    minWidth: 820,
    minHeight: 560,
    title: 'Audio ToolZ',
    icon: path.join(__dirname, 'public', 'icon.png'),
    backgroundColor: '#161820',
    autoHideMenuBar: true,
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });

  if (state.isMaximized) {
    win.maximize();
  }

  let saveTimer = null;
  const scheduleSave = () => {
    if (saveTimer) clearTimeout(saveTimer);
    saveTimer = setTimeout(() => saveWindowBounds(win), 180);
  };
  win.on('move', scheduleSave);
  win.on('resize', scheduleSave);
  win.on('close', () => saveWindowBounds(win));

  // Strict zero-internet enforcement
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('will-navigate', (event, url) => {
    if (!url.startsWith('file://')) event.preventDefault();
  });

  win.loadFile(path.join(__dirname, 'dist', 'index.html'));
}

app.whenReady().then(() => {
  session.defaultSession.setPermissionRequestHandler((_wc, permission, callback) => {
    callback(permission === 'media' || permission === 'audioCapture');
  });
  session.defaultSession.webRequest.onBeforeRequest((details, callback) => {
    const allow =
      details.url.startsWith('file://') ||
      details.url.startsWith('devtools://') ||
      details.url.startsWith('data:') ||
      details.url.startsWith('blob:');
    callback({ cancel: !allow });
  });
  createWindow();
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
