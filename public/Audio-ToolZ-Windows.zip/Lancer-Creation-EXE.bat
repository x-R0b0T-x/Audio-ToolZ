@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Creer-Audio-ToolZ-EXE.ps1"
pause
