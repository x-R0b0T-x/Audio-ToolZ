$ErrorActionPreference = "Stop"
Set-Location -Path $PSScriptRoot

Write-Host "======================================================" -ForegroundColor Cyan
Write-Host "  Installation des outils et creation de Audio ToolZ.exe" -ForegroundColor Cyan
Write-Host "======================================================" -ForegroundColor Cyan

# Etape 1 : Verifier / Installer Node.js LTS
if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
    if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
        Write-Error "Winget introuvable. Installez Node.js LTS depuis https://nodejs.org puis relancez."
        exit 1
    }
    Write-Host "[1/4] Telechargement et installation de Node.js LTS..." -ForegroundColor Yellow
    winget install --id OpenJS.NodeJS.LTS -e --accept-package-agreements --accept-source-agreements
    $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
} else {
    Write-Host "[1/4] Node.js deja installe : $(node -v)" -ForegroundColor Green
}

# Etape 2 : Installer Electron
Write-Host "[2/4] Telechargement et installation d'Electron..." -ForegroundColor Yellow
npm install --save-dev electron

# Etape 3 : Installer @electron/packager
Write-Host "[3/4] Telechargement et installation de @electron/packager..." -ForegroundColor Yellow
npm install --save-dev @electron/packager

# Etape 4 : Creer Audio ToolZ.exe avec icone integree + raccourci Bureau
Write-Host "[4/4] Creation de Audio ToolZ.exe avec icone Kick..." -ForegroundColor Yellow
npx @electron/packager . "Audio ToolZ" --platform=win32 --arch=x64 --icon=icon.ico --out=dist-exe --overwrite --ignore="^/dist-exe"

$ExePath = (Resolve-Path ".\dist-exe\Audio ToolZ-win32-x64\Audio ToolZ.exe").Path
$Desktop = [Environment]::GetFolderPath("Desktop")
$WshShell = New-Object -ComObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut((Join-Path $Desktop "Audio ToolZ.lnk"))
$Shortcut.TargetPath = $ExePath
$Shortcut.WorkingDirectory = Split-Path $ExePath
$Shortcut.IconLocation = "$ExePath,0"
$Shortcut.Save()

Write-Host ""
Write-Host "Termine ! Audio ToolZ.exe est pret (logo integre) :" -ForegroundColor Green
Write-Host "  $ExePath" -ForegroundColor White
Write-Host "Un raccourci 'Audio ToolZ' a aussi ete ajoute sur votre Bureau." -ForegroundColor Green
